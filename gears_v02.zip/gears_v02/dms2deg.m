function val = dms2deg(dd,mm,ss)
%DMS2DEG  Convert ddd:mm:ss to decimal degrees
    if nargin == 1
        val = dd;
    elseif nargin == 2
        val = dd + mm/60;
    else
        val = dd + mm/60 + ss/3600;
    end
end

