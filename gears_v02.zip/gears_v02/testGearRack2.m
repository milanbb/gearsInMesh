% test gearRack: test 2
addpath('..\draw2d')
close all

% create gear rack
m = 3; % modulus
alpha = dms2deg(15,45,0); % pressure angle
c = 0.25; % tip tooth clearance
a = gearRack(m,'-alpha',alpha,'-c',c);

%print rack data
print(a)
%print(a,'a.txt') % print to file 'a.txt'

%plot rack
plot(a)
%plot(a,'save') % to save figure

% generate gear with 7 teeth and prifil shift 0.2
gearGenerating(a,7,'-x',0.2)
%gearGenerating(a,7,'-x',0.2,'save') % to save figure

% shorten teeth height
a.u = 0.7;
gearGenerating(a,7,'-x',0.2)