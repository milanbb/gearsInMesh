% GEARS_V02
%
% Files
%   dms2deg                  - Convert ddd:mm:ss to decimal degrees
%   gear                     - Create gear object
%   gearRack                 - m -  Module
%   gearsInMesh              - Create gearsInMesh object
%   testGear0                - test 0 for gear: example from calculation-gear.xls program
%   testGear1                - test 1 for gear
%   testGear2                - test 2: export contour
%   testGearRack1            - test gearRack: test 1
%   testGearRack2            - test gearRack: test 2
%   testGearsInMesh          - test gearsInMesh
%   testGearsInMeshAnimation - test gearsInMesh animation
