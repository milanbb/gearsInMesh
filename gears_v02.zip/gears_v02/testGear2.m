% test 2: export contour
g1 = gear(gearRack(1),7);
plot(g1,'nocir','nocen')
% set 20 points to approximate profile
[X,Y] = gearContour(g1,'-nn',15);

% to export contour use
%[X,Y] = gearContour(g1,'-nn',20,'-fnam','test.txt');
scatter(X,Y,30,'k')
drawSave