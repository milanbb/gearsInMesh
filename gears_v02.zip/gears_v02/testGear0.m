% test 0 for gear: example from calculation-gear.xls program
% https://www.tec-science.com/
 addpath('..\draw2d') % the examples will work only with draw19 library
 close all
a = gearRack(1);
g1 = gear(a,18,'-x',0.352,'-beta',0);
print(g1)
plot(g1,'-nz',4)
g2 = gear(a,30,'-x',0.3,'-beta',0);
print(g2);
plot(g2,'-nz',4)
gm = gearsInMesh(g1,g2);
print(gm);
plot(gm,'-zoom',6,'-th1',30)
% animate(gm,'-zoom',6,'-dth1',1,'-nr',0.3)
% animat and save in a video file
% animate(gm,'-zoom',6,'-dth1',1,'save')

