% test 1 for gear
 addpath('..\draw2d') % the examples will work only with draw19 library
 close all
 
a = gear(gearRack(1),8,'-x',0,'-beta',0);
% plot rack
plot(a.rack)
% plot gear formation
gearGenerating(a.rack,8)
% print data
print(a)
%plot gear generation
plot(a,'gen')
% plot gaer using 4 teeth
plot(a,'-nz',4)
% add force to top,midle and bottom of the involute
plotForce(a, 0,1,'r')
plotForce(a,0.5,1,'r')
plotForce(a, 1,1,'b')

% set profile shift to aviod undercutting
a.x = a.xmin;
print(a)
plot(a,'gen')
plot(a,'-nz',4)
plotForce(a,0.5,1,'r')

% set tip shortening coefficient to avoid pointed teeth
a.u = 0.7;
print(a)
plot(a,'gen')
plot(a,'-nz',4)

% get some data about tooth at radius in middle of top and base
getData(a,getPar(a,0.5*(a.Ra+a.Rb)))

