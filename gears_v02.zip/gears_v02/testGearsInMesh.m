% test gearsInMesh
 addpath('..\draw2d') % the examples will work only with draw19 library
 close all
 
a = gearRack(1);
G1 = gear(a,5);
G2 = gear(a,9);
drawSet('LineWidth',2)
plot(G1)
plot(G2)
GM=gearsInMesh(G1,G2);
plot(GM,'-th1',30) 
print(GM)
% set profile shift
GM.G1.x = GM.G1.xmin;
GM.G2.x = GM.G2.xmin;
plot(GM,'-th1',30) 
print(GM)