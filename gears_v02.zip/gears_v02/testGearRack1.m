% test gearRack: test 1
addpath('..\draw2d') % change this if path is different
close all

% create gear rack
m = 3; % modulus
a = gearRack(m);

%print rack data
print(a)
%print(a,'a.txt') % print to file 'a.txt'

%plot rack
plot(a)

% generate gear with 7 teeth
gearGenerating(a,7)