% test gearsInMesh animation
 addpath('..\draw2d') % the examples will work only with draw19 library
 %if this library is in gaers folder use
 %addpath('draw2d')
 close all
 
aa = gearRack(1);
G1 = gear(aa,8);
G2 = gear(aa,13);
plot(G1)
plot(G2)
GM=gearsInMesh(G1,G2);
% animate 0.4 turn of gear 1
animate(GM,'-zoom',4,'-nr',0.4)
% for interactive control of rotation use
% animate(GM,'-zoom',4,'-step','on','-nr',0.3)

